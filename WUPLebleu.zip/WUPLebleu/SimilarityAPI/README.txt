It gives interface for wup similarity score calculation through python 
Usage:
java -cp similarityapi.jar:py4j-0.10.5.jar:. Score
