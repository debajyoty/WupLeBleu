import lebleu as lb

l = lb.LeBLEU()
# c = l.eval_single("I am good boy", "I am good person")
h = lb.HindiModifiedLeBLEU()
d = h.eval_single("हम दोनों विद्यालय","हम दोनों स्कूल")
c = l.eval_single("हम दोनों विद्यालय","हम दोनों स्कूल")
print(d)
print('actual')
print(c)