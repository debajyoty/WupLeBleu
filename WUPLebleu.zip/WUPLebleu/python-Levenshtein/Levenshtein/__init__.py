from Levenshtein import _levenshtein
from Levenshtein._levenshtein import *

__doc__ = _levenshtein.__doc__    
